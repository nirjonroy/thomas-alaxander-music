<style>
   /* Styles for the slider container */
   
   /* Styles for the big image */
   .slider-image {
   width: 88%;
    height: auto;
    display: block;
   }

</style>
       
        <!-- Big Image -->

        <a href="" class="popup-link">
            <img class="slider-image img-thumbnail" id="big-image" src="{{asset($image_array)}}" alt="Image 1">
        </a>


