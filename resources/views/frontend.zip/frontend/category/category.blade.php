@extends('frontend.app')
@section('title', 'Category List')
@section('content')


@endsection